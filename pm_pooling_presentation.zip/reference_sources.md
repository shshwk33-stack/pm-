# 참고문헌·자료 출처 메모

표지·참고문헌 슬라이드는 사용자가 작성합니다. 본문 슬라이드의 [1]–[3]은 아래 문헌과 연결됩니다. 문헌의 숫자나 결과를 본 연구 성과로 재사용하지 않았습니다.

[1] G. B. Dantzig, J. H. Ramser (1959). The Truck Dispatching Problem. Management Science, 6(1), 80–91.
https://doi.org/10.1287/mnsc.6.1.80

[2] M. Gansterer, R. F. Hartl (2018). Collaborative vehicle routing: A survey. European Journal of Operational Research, 268(1), 1–12.
https://doi.org/10.1016/j.ejor.2017.10.023

[3] G. Lee, J. S. Lee, K. S. Park (2024). Battery swapping, vehicle rebalancing, and staff routing for electric scooter sharing systems. Transportation Research Part E: Logistics and Transportation Review, 186, 103540.
https://www.sciencedirect.com/science/article/pii/S1366554524001315

[4] S. Elting, J. F. Ehmke, M. Gansterer (2024). Collaborative Transportation for Attended Home Deliveries. Networks.
https://doi.org/10.1002/net.22216

[5] Google (공식 자료). OR-Tools: Open Source Tools for Optimization. Official project documentation.
https://github.com/google/or-tools

[6] MobilityData (공식 자료). General Bikeshare Feed Specification. Official open data specification.
https://github.com/MobilityData/gbfs

## 데이터·연구자료

도로 OD: Kakao Mobility API. https://developers.kakaomobility.com/ — 기존 저장 응답 사용, 이번 PPT 제작의 새 API 호출 0.
관측 데이터: 프로젝트의 pm_snapshot.csv 및 메타데이터. 선택 권역163대(GBIKE155/ALPACA8), 실제 관측시각은 확인되지 않음. 실행 폴더의 날짜를 관측일자로 표기하지 않음.
기존 수상작: 2025 제15회 KSCM 산업응용 프로젝트 경진대회(대학부), 「공유 퍼스널 모빌리티(pm) 풀링시스템: 전동킥보드 운영 최적화를 중심으로」. 김민우·조원재·고경민·최준수. 사용자가 제공한 원본23장.

## 확인 수준과 인용 범위

출판사·Crossref 직접 조회는 프록시403으로 차단되었습니다. 이를 직접 검증했다고 표시하지 않았습니다. Dantzig는 기존 첨부 서지, Gansterer는 실제 읽은 학술발표 PDF 참고문헌, Lee는 실제 읽은 학위논문의 운영 설명과 참고문헌, Elting은 원저자 코드 저장소에서 서지를 확인했습니다. 공식 OR-Tools·GBFS 문서는 직접 확인했습니다. 세부 증빙과 SHA-256은 research_notes/sources.json 및 literature.md에 있습니다.
원저의 연구모형·실험을 완독한 것으로 설명하지 않으며 분야 전체에 선행연구가 없다는 주장도 하지 않습니다. 초기 계획서의 Leurent(2024)는 서지를 확인하지 못해 최종 인용에서 제외했습니다.
GBFS는 선택적 보조 출처입니다. 현재 데이터가 GBFS로 수집되거나 실시간 표준 연동을 실증했다고 쓰지 마세요.