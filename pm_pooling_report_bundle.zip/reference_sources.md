# 본문 문헌·데이터 출처

표지·참고문헌 슬라이드는 포함하지 않았습니다. 본문의 문헌 [1]–[3]은 다음 자료입니다.

1. Dantzig, G. B., & Ramser, J. H. (1959). The Truck Dispatching Problem.
   *Management Science, 6*(1), 80–91. https://doi.org/10.1287/mnsc.6.1.80
2. Gansterer, M., & Hartl, R. F. (2018). Collaborative vehicle routing: A survey.
   *European Journal of Operational Research, 268*(1), 1–12.
   https://doi.org/10.1016/j.ejor.2017.10.023
3. Lee, G., Lee, J. S., & Park, K. S. (2024). Battery swapping, vehicle rebalancing,
   and staff routing for electric scooter sharing systems.
   *Transportation Research Part E: Logistics and Transportation Review, 186*, 103540.
   https://www.sciencedirect.com/science/article/pii/S1366554524001315

문헌은 차량경로계획·협력 운송·공유 PM 운영의 배경을 설명하는 데 사용했습니다.
원저의 실험 성과를 이번 연구 수치로 사용하지 않았습니다. 서지는 첨부자료 및
실제 확인한 학술자료의 참고문헌을 대조한 범위이며, 모든 원저를 완독하거나
분야 전체의 선행연구 부재를 확인했다는 의미는 아닙니다.

## 연구자료 약호

- [D1] 동결된 실제 관측 좌표 기반 사례:
  `outputs/observed_20261006T105904_539879Z`.
  163대(GBIKE 155·ALPACA 8), 45개 서비스 노드, 단일 가상 Depot,
  새 방향별 도로 OD, A/B/C 경로·수요·시간·비교표.
  실행 폴더 날짜는 실제 관측일자를 뜻하지 않습니다.
- [D2] `outputs/multi_operator_extension_20261007T043600_486058Z`.
  최종 30실행 조건(기존 2개사 6조건＋3·4개사 24조건), 구성·소속 배정·혼합도.
- [D3] `outputs/robustness_20261007T045249_578327Z` 및 연구 README.
  적재용량 5수준, 탐색당 시간 3수준, Q100 가상 구성 교차확인 2조건.
- [D4] 사용자 제공 최종 개발자 ZIP의 Dashboard 저장결과 조회 화면.
  기존 캐시를 사용한 화면이며 실제 상용 운영·Live 실행 성공을 증명하지 않습니다.
- [D5] 저장된 41case·294개 경로의 독립 읽기 전용 감사.
  정확히 1회 처리, 용량, 방향 OD 거리·시간 합, 작업시간 분해,
  배터리 종류별 수량 보존을 검산했습니다. 전체 pytest 재실행과 구분합니다.
- [P1] 2025 제15회 KSCM 산업응용 프로젝트 경진대회 기존 발표,
  「공유 퍼스널 모빌리티(pm) 풀링시스템: 전동킥보드 운영 최적화를 중심으로」.
  사용자 제공 원본 23장과 비교했습니다. 과거 기대효과를 새 결과로 재사용하지 않았습니다.

도로 거리·시간: Kakao Mobility API의 기존 저장 응답.
https://developers.kakaomobility.com/

경로 계산 도구: Google OR-Tools. https://github.com/google/or-tools
제한시간 휴리스틱 탐색의 거리 전역최적성은 증명되지 않았습니다.
